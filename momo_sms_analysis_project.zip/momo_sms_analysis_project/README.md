# MoMo SMS Analysis Project

## Overview

This project analyzes MTN MoMo transaction SMS data stored in XML format. It parses, categorizes, and stores transactions in a database, and presents them in a fully responsive frontend dashboard with filtering and charting capabilities.

## Features

- XML SMS parsing with regex
- Categorization of transactions
- SQLite database integration
- RESTful Flask API
- Interactive JavaScript dashboard
- Responsive charts with Chart.js
- Category filters and search with autocomplete

## Technologies Used

- Python 3
- Flask
- SQLite
- HTML5, CSS3, JavaScript
- Chart.js

## Setup Instructions

1. Run `insert_to_db.py` to populate the database:
   ```bash
   python backend/insert_to_db.py
   ```

2. Start the Flask API server:
   ```bash
   python backend/api.py
   ```

3. Open `frontend/index.html` in your browser.

## File Structure

- `data/modified_sms_v2.xml`: Raw SMS input
- `backend/`: Python scripts and database
- `frontend/`: HTML/CSS/JS files for dashboard
- `sms.db`: Generated SQLite database
- `REPORT.pdf`: Final project report

## Author

See [AUTHOR](AUTHOR)

## License

This project is part of a university assignment and is not licensed for commercial use.
